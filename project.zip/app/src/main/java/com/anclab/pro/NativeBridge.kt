package com.anclab.pro

object NativeBridge {
    init { System.loadLibrary("anclab") }
    external fun nativeStart(outId: Int, inId: Int, gain: Float): Int   // 0 ok, 1 out fail, 2 in fail, 3 start fail
    external fun nativeStop()
    external fun nativeEmergencyStop()
    external fun nativeSetGain(g: Float)
    external fun nativeStats(): DoubleArray                            // -1.0 == "No medida"
    external fun nativeSnapshot(out: FloatArray)
    external fun nativeSimulate(tonal: Boolean, pDelay: Int, sDelay: Int, mu: Float): Double
}
