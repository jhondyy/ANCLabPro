package com.anclab.pro

import kotlin.math.*

/** Hann-windowed radix-2 FFT. Returns linear amplitude per bin (n/2 bins), 1.0 == full-scale sine. */
fun fftMag(x: FloatArray): FloatArray {
    val n = x.size
    val re = DoubleArray(n) { x[it] * (0.5 - 0.5 * cos(2 * PI * it / (n - 1))) }
    val im = DoubleArray(n)
    var j = 0
    for (i in 1 until n) {
        var bit = n shr 1
        while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
        j = j xor bit
        if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t }
    }
    var len = 2
    while (len <= n) {
        val ang = -2 * PI / len
        for (i in 0 until n step len) for (k in 0 until len / 2) {
            val wr = cos(ang * k); val wi = sin(ang * k)
            val a = i + k; val b = i + k + len / 2
            val xr = re[b] * wr - im[b] * wi; val xi = re[b] * wi + im[b] * wr
            re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi
        }
        len = len shl 1
    }
    return FloatArray(n / 2) { (sqrt(re[it] * re[it] + im[it] * im[it]) / (n / 4.0)).toFloat() }
}

val BAND_CENTERS = intArrayOf(125, 250, 500, 1000, 2000, 4000, 8000)

/** Octave-band level in dBFS (relative) from FFT magnitudes. */
fun bandLevels(mag: FloatArray, fs: Double): DoubleArray {
    val binHz = fs / 2 / mag.size
    return DoubleArray(BAND_CENTERS.size) { b ->
        val lo = BAND_CENTERS[b] / sqrt(2.0); val hi = BAND_CENTERS[b] * sqrt(2.0)
        var p = 0.0
        for (i in mag.indices) { val f = i * binHz; if (f >= lo && f < hi) p += mag[i] * mag[i] / 2.0 }
        10 * log10(p + 1e-12)
    }
}
